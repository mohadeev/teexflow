const { WebSocketServer } = require('ws');
const http = require('http');

const server = http.createServer();
const wss = new WebSocketServer({ server });

// Store rooms and their clients
const rooms = new Map(); // roomCode -> Set of WebSocket clients

wss.on('connection', (ws, req) => {
  // Extract room from URL: ws://host:8080?room=ABC123
  const url = new URL(req.url, 'http://localhost');
  const roomCode = url.searchParams.get('room');
  if (!roomCode) {
    ws.close(1008, 'Missing room parameter');
    return;
  }

  // Join room
  if (!rooms.has(roomCode)) {
    rooms.set(roomCode, new Set());
  }
  rooms.get(roomCode).add(ws);
  console.log(`Client joined room ${roomCode}, total clients: ${rooms.get(roomCode).size}`);

  // Forward broadcast messages to all clients in the same room (except sender)
  ws.on('message', (data) => {
    try {
      const message = JSON.parse(data);
      const clients = rooms.get(roomCode);
      if (!clients) return;

      // Broadcast to all other clients in the room
      const payload = JSON.stringify(message);
      for (const client of clients) {
        if (client !== ws && client.readyState === 1) {
          client.send(payload);
        }
      }
    } catch (err) {
      console.error('Invalid message:', err);
    }
  });

  ws.on('close', () => {
    const clients = rooms.get(roomCode);
    if (clients) {
      clients.delete(ws);
      if (clients.size === 0) {
        rooms.delete(roomCode);
      }
      console.log(`Client left room ${roomCode}, remaining: ${clients.size}`);
    }
  });
});

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`WebSocket server running on port ${PORT}`);
});