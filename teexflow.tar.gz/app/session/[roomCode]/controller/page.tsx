'use client'

import { useParams, useRouter } from 'next/navigation'
import { useEffect, useRef, useState } from 'react'
import { supabase } from '@/lib/supabase'
import Link from 'next/link'
import { useRoomSync } from '@/hooks/useRoomSync'

type Script = { id: string; title: string; content: string }

export default function ControllerPage() {
  const { roomCode } = useParams()
  const router = useRouter()
  const [script, setScript] = useState<Script | null>(null)
  const { playing, speed, scrollPercentage, isConnected, sendControl, sendScroll } = useRoomSync(roomCode as string)
  const previewRef = useRef<HTMLDivElement>(null)
  const animationRef = useRef<number | null>(null)
  const isRemoteScrollRef = useRef(false)

  // Load script
  useEffect(() => {
    const fetchData = async () => {
      const { data: sessionData, error: sessionError } = await supabase
        .from('sessions')
        .select('script_id')
        .eq('room_code', roomCode)
        .maybeSingle()
      if (sessionError || !sessionData) {
        alert('Session not found.')
        router.push('/dashboard')
        return
      }
      const { data: scriptData, error: scriptError } = await supabase
        .from('scripts')
        .select('*')
        .eq('id', sessionData.script_id)
        .maybeSingle()
      if (scriptError || !scriptData) {
        alert('Script not found.')
        router.push('/dashboard')
        return
      }
      setScript(scriptData)
      // Apply initial scroll percentage (from DB or received via WS)
      // We'll get it from WS subscription
    }
    fetchData()
  }, [roomCode, router])

  // Apply remote scroll
  useEffect(() => {
    if (!previewRef.current) return
    const container = previewRef.current
    const maxScroll = container.scrollHeight - container.clientHeight
    const target = (scrollPercentage / 100) * maxScroll
    isRemoteScrollRef.current = true
    container.scrollTop = target
    setTimeout(() => { isRemoteScrollRef.current = false }, 50)
  }, [scrollPercentage])

  // Handle manual scroll
  const handleScroll = () => {
    if (!previewRef.current || isRemoteScrollRef.current) return
    const container = previewRef.current
    const maxScroll = container.scrollHeight - container.clientHeight
    if (maxScroll <= 0) return
    const percentage = (container.scrollTop / maxScroll) * 100
    sendScroll(percentage)
    // persist to DB (optional)
    supabase.from('sessions').update({ scroll_percentage: percentage }).eq('room_code', roomCode)
  }

  // Auto‑scroll loop
  useEffect(() => {
    if (!playing || !previewRef.current || !script) {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
      return
    }

    let lastTime = performance.now()
    let accumulated = 0

    const step = (time: number) => {
      const delta = (time - lastTime) / 1000
      lastTime = time
      accumulated += delta * speed

      const container = previewRef.current!
      const maxScroll = container.scrollHeight - container.clientHeight
      const newScroll = Math.min(container.scrollTop + accumulated, maxScroll)
      container.scrollTop = newScroll
      accumulated = 0

      // Broadcast scroll position
      if (maxScroll > 0) {
        const percentage = (container.scrollTop / maxScroll) * 100
        sendScroll(percentage)
      }

      if (newScroll < maxScroll && playing) {
        animationRef.current = requestAnimationFrame(step)
      }
    }

    animationRef.current = requestAnimationFrame(step)
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current)
    }
  }, [playing, speed, script, sendScroll])

  const togglePlay = () => {
    sendControl(playing ? 'pause' : 'play')
    supabase.from('sessions').update({ status: playing ? 'paused' : 'playing' }).eq('room_code', roomCode)
  }

  const changeSpeed = (newSpeed: number) => {
    const clamped = Math.min(300, Math.max(5, newSpeed))
    sendControl('speed', { speed: clamped })
    supabase.from('sessions').update({ scroll_speed: clamped }).eq('room_code', roomCode)
  }

  if (!script) return <div>Loading...</div>

  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">{script.title}</h1>
            <p className="text-sm text-white/40">Room: {roomCode} {isConnected ? '🟢' : '🔴'}</p>
          </div>
          <Link href="/dashboard" className="text-sm text-white/60 hover:text-white px-4 py-2 rounded-xl border border-white/10 hover:border-white/30 transition">
            Exit Session
          </Link>
        </div>

        <div className="bg-[#121316] border border-white/5 rounded-2xl p-6 mb-6 flex flex-wrap items-center gap-4">
          <button onClick={togglePlay} className={`px-6 py-3 rounded-xl font-medium transition ${playing ? 'bg-white/10 text-white hover:bg-white/20' : 'bg-white text-black hover:bg-white/90'}`}>
            {playing ? '⏸ Pause' : '▶ Play'}
          </button>
          <div className="flex items-center gap-3">
            <span className="text-sm text-white/40">Speed:</span>
            <button onClick={() => changeSpeed(speed - 10)} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white/60 flex items-center justify-center text-sm">−</button>
            <input type="range" min="5" max="300" step="5" value={speed} onChange={(e) => changeSpeed(parseInt(e.target.value))} className="w-40 accent-[#0A84FF]" />
            <button onClick={() => changeSpeed(speed + 10)} className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 text-white/60 flex items-center justify-center text-sm">+</button>
            <span className="text-sm text-white/60 min-w-[3rem]">{speed} px/s</span>
          </div>
        </div>

        <div className="relative">
          <div
            ref={previewRef}
            onScroll={handleScroll}
            className="h-[600px] overflow-y-auto bg-[#121316] border border-white/5 rounded-2xl p-8 scroll-smooth"
            style={{ scrollbarWidth: 'thin', scrollbarColor: '#333 transparent' }}
          >
            <div className="max-w-2xl mx-auto text-lg leading-relaxed whitespace-pre-wrap text-white/80">
              {script.content}
            </div>
          </div>
          <div className="absolute top-1/2 left-0 right-0 -translate-y-1/2 pointer-events-none flex items-center justify-center">
            <div className="max-w-2xl mx-auto relative w-full">
              <div className="h-0.5 bg-red-500/60 shadow-[0_0_8px_rgba(255,0,0,0.4)] w-full" />
            </div>
          </div>
        </div>

        <div className="mt-3 text-xs text-white/30 flex justify-between">
          <span>{playing ? '● Live' : '⏸ Paused'}</span>
          <span>Speed: {speed} px/s</span>
        </div>
      </div>
    </div>
  )
}