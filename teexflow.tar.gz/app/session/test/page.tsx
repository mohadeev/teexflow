'use client'

import { useEffect, useState } from 'react'
import { useUser } from '@clerk/nextjs'
import { supabase } from '@/lib/supabase'

type Script = {
  id: string
  title: string
  sections: any[]
  created_at: string
}

export default function TestPage() {
  const { user, isLoaded, isSignedIn } = useUser()
  const [scripts, setScripts] = useState<Script[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [creating, setCreating] = useState<string | null>(null) // script id being processed

  // Load scripts when user is ready
  useEffect(() => {
    async function loadScripts() {
      if (!isLoaded) return
      if (!isSignedIn) {
        setError('Please sign in first.')
        setLoading(false)
        return
      }

      try {
        const { data, error } = await supabase
          .from('scripts')
          .select('*')
          .eq('user_id', user.id)
          .order('created_at', { ascending: false })

        if (error) throw error
        setScripts(data || [])
      } catch (err: any) {
        console.error('Load scripts error:', err)
        setError(err.message || 'Failed to load scripts')
      } finally {
        setLoading(false)
      }
    }

    loadScripts()
  }, [isLoaded, isSignedIn, user])

  // Handle starting a session for a script
  async function startSession(scriptId: string) {
    setCreating(scriptId)
    try {
      const roomCode = Math.random().toString(36).substring(2, 8).toUpperCase()
      const { data, error } = await supabase
        .from('sessions')
        .insert({
          script_id: scriptId,
          room_code: roomCode,
          status: 'idle',
          current_section_index: 0,
          scroll_speed: 30,
        })
        .select()
        .single()

      if (error) throw error

      // Redirect to controller page
      window.location.href = `/session/${roomCode}/controller`
    } catch (err: any) {
      console.error('Start session error:', err)
      alert(`Failed to start session: ${err.message}`)
    } finally {
      setCreating(null)
    }
  }

  // Loading state
  if (!isLoaded || loading) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-white flex items-center justify-center">
        <p className="text-white/60">Loading scripts...</p>
      </div>
    )
  }

  // Error state
  if (error) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-white flex flex-col items-center justify-center p-8">
        <h1 className="text-2xl text-red-500 mb-4">Error</h1>
        <p className="text-white/60">{error}</p>
        <p className="text-xs text-white/30 mt-4">
          Make sure you’re signed in and RLS is disabled on `scripts` and `sessions`.
        </p>
      </div>
    )
  }

  // No scripts
  if (scripts.length === 0) {
    return (
      <div className="min-h-screen bg-[#0A0A0B] text-white flex flex-col items-center justify-center p-8">
        <h1 className="text-2xl mb-4">No scripts found</h1>
        <p className="text-white/60 mb-4">Create one using the dashboard or test page.</p>
        <p className="text-xs text-white/30">(Make sure you have at least one script in your `scripts` table.)</p>
      </div>
    )
  }

  // Display scripts
  return (
    <div className="min-h-screen bg-[#0A0A0B] text-white p-8">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-bold">Your Scripts</h1>
          <span className="text-sm text-white/40">{scripts.length} total</span>
        </div>

        <div className="space-y-4">
          {scripts.map((script) => (
            <div
              key={script.id}
              className="bg-[#121316] border border-white/5 rounded-2xl p-6 flex items-center justify-between hover:border-white/10 transition"
            >
              <div>
                <h2 className="text-xl font-medium">{script.title}</h2>
                <p className="text-sm text-white/40">
                  {script.sections?.length || 0} sections · {new Date(script.created_at).toLocaleDateString()}
                </p>
              </div>
              <button
                onClick={() => startSession(script.id)}
                disabled={creating === script.id}
                className="bg-[#0A84FF] text-white px-4 py-2 rounded-xl text-sm hover:bg-[#0A84FF]/90 transition disabled:opacity-50"
              >
                {creating === script.id ? 'Starting...' : 'Start Session'}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}