import Link from 'next/link'
import { SignInButton, UserButton } from '@clerk/nextjs'
import { auth } from '@clerk/nextjs/server'

export default async function HomePage() {
  const { userId } = await auth()
  const isSignedIn = !!userId

  return (
    <main className="min-h-screen bg-[#0A0A0B] text-white font-sans antialiased overflow-x-hidden">
      {/* Navigation */}
      <header className="max-w-7xl mx-auto px-6 py-6 flex items-center justify-between border-b border-white/5 relative z-10">
        <div className="flex items-center gap-2">
          <span className="text-2xl font-semibold tracking-tight">TeexFlow</span>
          <span className="text-xs bg-white/10 px-2 py-0.5 rounded-full text-white/60">beta</span>
        </div>

        <nav className="hidden md:flex items-center gap-8 text-sm text-white/60">
          <Link href="#features" className="hover:text-white transition">Features</Link>
          <Link href="#pricing" className="hover:text-white transition">Pricing</Link>
          <a href="#" className="hover:text-white transition">Docs</a>
        </nav>

        <div className="flex items-center gap-4">
          {isSignedIn ? (
            <>
              <Link
                href="/dashboard"
                className="text-sm bg-white text-black px-4 py-2 rounded-xl font-medium hover:bg-white/90 transition"
              >
                Dashboard
              </Link>
              <UserButton />
            </>
          ) : (
            <>
              <SignInButton mode="modal">
                <button className="text-sm text-white/60 hover:text-white transition">Log in</button>
              </SignInButton>
              <SignInButton mode="modal">
                <button className="text-sm bg-white text-black px-4 py-2 rounded-xl font-medium hover:bg-white/90 transition shadow-lg shadow-white/10">
                  Get started
                </button>
              </SignInButton>
            </>
          )}
        </div>
      </header>

      {/* Hero with radial gradient */}
      <section className="relative max-w-5xl mx-auto px-6 pt-20 pb-32 text-center overflow-hidden">
        {/* Gradient orbs */}
        <div className="absolute top-[-30%] left-1/2 -translate-x-1/2 w-[800px] h-[800px] rounded-full bg-[#0A84FF]/5 blur-3xl pointer-events-none" />
        <div className="absolute top-[-20%] right-[-10%] w-[500px] h-[500px] rounded-full bg-[#0A84FF]/10 blur-3xl pointer-events-none" />
        
        <div className="relative z-10">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tight leading-[1.1]">
            The AI teleprompter that<br />
            <span className="bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA] bg-clip-text text-transparent">
              follows your voice
            </span>
          </h1>
          <p className="mt-6 text-lg md:text-xl text-white/60 max-w-2xl mx-auto">
            TeexFlow lets your script move with you – not the other way around. 
            Control from your laptop, display on your tablet, and optionally let AI track your speech.
          </p>
          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4">
            <SignInButton mode="modal">
              <button className="bg-gradient-to-r from-white to-white/90 text-black px-8 py-4 rounded-2xl text-lg font-medium hover:scale-[1.02] transition shadow-2xl shadow-[#0A84FF]/20">
                Start free trial
              </button>
            </SignInButton>
            <a
              href="#demo"
              className="text-white/60 hover:text-white transition flex items-center gap-2"
            >
              <span className="w-10 h-10 rounded-full border border-white/10 flex items-center justify-center hover:bg-white/5 transition">
                ▶
              </span>
              Watch demo
            </a>
          </div>
          <p className="mt-4 text-sm text-white/40">No credit card required • Free plan available</p>
        </div>

        {/* Hero visual */}
        <div className="relative z-10 mt-16 rounded-2xl bg-[#121316] border border-white/5 p-4 aspect-video flex items-center justify-center text-white/30 shadow-2xl shadow-black/20">
          <span className="text-lg">🎥 Demo video placeholder</span>
        </div>
      </section>

      {/* Features with gradient hover borders */}
      <section id="features" className="max-w-6xl mx-auto px-6 py-24 border-t border-white/5">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold">
            Designed for <span className="bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA] bg-clip-text text-transparent">natural delivery</span>
          </h2>
          <p className="mt-4 text-white/60 text-lg">Everything you need to speak confidently, without looking at your notes.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div 
              key={feature.title} 
              className="group bg-[#121316] rounded-2xl p-8 border border-white/5 hover:border-transparent hover:bg-gradient-to-b hover:from-[#121316] hover:to-[#1A1A1F] transition-all duration-300 relative"
            >
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-[#0A84FF]/0 via-[#0A84FF]/0 to-[#5AC8FA]/0 group-hover:from-[#0A84FF]/10 group-hover:via-[#0A84FF]/5 group-hover:to-[#5AC8FA]/10 transition duration-300 pointer-events-none" />
              <div className="relative z-10">
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold">{feature.title}</h3>
                <p className="mt-2 text-white/50 text-sm leading-relaxed">{feature.description}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* How it works – subtle gradient on accent */}
      <section className="max-w-5xl mx-auto px-6 py-24 border-t border-white/5">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-sm text-[#0A84FF] font-medium bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA] bg-clip-text text-transparent">
              Real‑time sync
            </span>
            <h2 className="text-3xl md:text-4xl font-bold mt-2">Control from your laptop, read from your tablet</h2>
            <p className="mt-4 text-white/60">
              The controller dashboard gives you full command – play, pause, jump sections, adjust speed. 
              The teleprompter display shows only the script, beautifully rendered.
            </p>
            <ul className="mt-6 space-y-3 text-sm">
              {['Instant updates via WebSocket', 'Section highlighting', 'Adjustable scroll speed'].map((item) => (
                <li key={item} className="flex items-center gap-3 text-white/80">
                  <span className="w-1.5 h-1.5 rounded-full bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA]" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
          <div className="bg-[#121316] rounded-2xl border border-white/5 p-6 aspect-[4/3] flex items-center justify-center text-white/30 shadow-xl shadow-black/10">
            <span>📱 Controller UI mockup</span>
          </div>
        </div>
      </section>

      {/* Pricing with gradient on popular plan */}
      <section id="pricing" className="max-w-6xl mx-auto px-6 py-24 border-t border-white/5">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold">
            Simple, <span className="bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA] bg-clip-text text-transparent">transparent</span> pricing
          </h2>
          <p className="mt-4 text-white/60 text-lg">Start for free, upgrade when you need more.</p>
        </div>

        <div className="grid md:grid-cols-4 gap-6">
          {pricingPlans.map((plan) => (
            <div
              key={plan.name}
              className={`bg-[#121316] rounded-2xl p-8 border flex flex-col transition-all duration-300 ${
                plan.popular
                  ? 'border-[#0A84FF]/40 shadow-xl shadow-[#0A84FF]/10 bg-gradient-to-b from-[#121316] to-[#1A1A2E]'
                  : 'border-white/5 hover:border-white/10'
              }`}
            >
              <div>
                <h3 className="text-lg font-semibold">{plan.name}</h3>
                <div className="mt-4">
                  <span className="text-3xl font-bold">{plan.price}</span>
                  {plan.price !== 'Free' && <span className="text-white/40 text-sm ml-1">/mo</span>}
                </div>
                <ul className="mt-6 space-y-3 text-sm">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-2 text-white/70">
                      <span className="text-[#0A84FF] mt-0.5">✓</span>
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              <div className="mt-8">
                <SignInButton mode="modal">
                  <button
                    className={`w-full py-3 rounded-xl text-sm font-medium transition ${
                      plan.popular
                        ? 'bg-gradient-to-r from-[#0A84FF] to-[#5AC8FA] text-white hover:opacity-90 shadow-lg shadow-[#0A84FF]/25'
                        : 'bg-white/10 text-white hover:bg-white/20'
                    }`}
                  >
                    {plan.cta}
                  </button>
                </SignInButton>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-white/5 text-sm text-white/40 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center gap-6">
          <span className="font-semibold text-white/60">TeexFlow</span>
          <span>© 2026</span>
        </div>
        <div className="flex gap-6 mt-4 md:mt-0">
          <a href="#" className="hover:text-white transition">Privacy</a>
          <a href="#" className="hover:text-white transition">Terms</a>
          <a href="#" className="hover:text-white transition">Support</a>
        </div>
      </footer>
    </main>
  )
}

// Data (unchanged)
const features = [
  {
    icon: '🎯',
    title: 'Voice Tracking',
    description: 'Optional AI that listens and automatically adjusts the script position as you speak.',
  },
  {
    icon: '⚡',
    title: 'Real‑time Sync',
    description: 'Laptop controls update the tablet instantly – zero lag, no refresh needed.',
  },
  {
    icon: '📱',
    title: 'Clean Display',
    description: 'Full‑screen, distraction‑free teleprompter with smooth scrolling and section highlights.',
  },
]

const pricingPlans = [
  {
    name: 'Free',
    price: 'Free',
    features: ['Limited scripts', 'Basic teleprompter', 'Manual control'],
    cta: 'Get started',
    popular: false,
  },
  {
    name: 'Pro',
    price: '€10',
    features: ['Unlimited scripts', 'Real‑time control', 'Session system', 'Speed control'],
    cta: 'Upgrade',
    popular: false,
  },
  {
    name: 'Creator Pro',
    price: '€25',
    features: ['Voice tracking (beta)', 'Advanced navigation', 'Performance tools', 'Priority support'],
    cta: 'Upgrade',
    popular: true,
  },
  {
    name: 'Studio',
    price: '€100',
    features: ['Teams & collaboration', 'Multi‑device sessions', 'Production workflows', 'Dedicated support'],
    cta: 'Contact sales',
    popular: false,
  },
]