import { createClient } from '@supabase/supabase-js'

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Helper to set the Clerk JWT on Supabase
export async function setSupabaseToken(token: string) {
  // Using setSession allows us to pass a JWT as the access_token
  // The refresh_token can be empty; Supabase will use the access_token for auth.
  await supabase.auth.setSession({
    access_token: token,
    refresh_token: '', // not needed for Clerk integration
  })
}